(function() {
  'use strict';
  
  angular
    .module('testApp')
    .controller('TestCtrl', ['$scope', TestCtrl]);
  
  function TestCtrl(scope) {
    scope.emps = [
      {id: 1, firstName: 'Ashish', lastName: 'Kumar'},
      {id: 2, firstName: 'Parma', lastName: 'Dhuri'},
      {id: 3, firstName: 'Kedar', lastName: 'Naik'},
      {id: 4, firstName: 'Rahul', lastName: 'Pandey'},
      {id: 5, firstName: 'Kundan', lastName: 'Shinde'}
    ];
  }
}());