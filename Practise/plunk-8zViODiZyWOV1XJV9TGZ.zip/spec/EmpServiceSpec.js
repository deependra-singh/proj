(function() {
  'use strict';
  
  describe('Service', function() {
    describe('Emp Service', function() {
      var empService;
      
      beforeEach(module('testApp'));
      beforeEach(inject(function(EmpService) {
        empService = EmpService;
      }));
      
      it('has size 5', function() {
        var size = empService.allEmps().length;
        expect(size).toBe(5);
      });
      
      it('has allEmp Method', function() {
        expect(true).toBe(true);
      });
      
    });
  });
}());