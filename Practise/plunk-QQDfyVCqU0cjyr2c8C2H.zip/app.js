(function(){
  'use strict';
  angular
  .module('testApp', [])
  .controller('TestCtrl', function($scope) {
     $scope.message = 'Hello World';
  })
  .controller('FirstTestCtrl', function($scope) {
    $scope.name = 'I';
  })
  .controller('AddCtrl', function ($scope){
    $scope.add=function(num1,num2){
      num1 = parseInt(num1);
      num2 = parseInt(num2);
      $scope.sum = num1+num2;
    }
  });
}());